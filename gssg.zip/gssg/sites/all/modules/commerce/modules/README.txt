This directory contains the various core Drupal Commerce modules.
